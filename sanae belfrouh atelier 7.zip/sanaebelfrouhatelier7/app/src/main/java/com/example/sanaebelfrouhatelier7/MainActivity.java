package com.example.sanaebelfrouhatelier7;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] linear_acceleration = new float[3];
    private TextView statusTextView;
    private TextView activityStandingConfidenceTextView;
    private TextView activitySittingConfidenceTextView;
    private TextView activityWalkingConfidenceTextView;
    private TextView activityJumpingConfidenceTextView;

    private int[] confidenceValues = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        statusTextView = findViewById(R.id.statusTextView);
        activityStandingConfidenceTextView = findViewById(R.id.activityStandingConfidenceTextView);
        activitySittingConfidenceTextView = findViewById(R.id.activitySittingConfidenceTextView);
        activityWalkingConfidenceTextView = findViewById(R.id.activityWalkingConfidenceTextView);
        activityJumpingConfidenceTextView = findViewById(R.id.activityJumpingConfidenceTextView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final float alpha = 0.8f;
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            linear_acceleration[0] = event.values[0] - gravity[0];
            linear_acceleration[1] = event.values[1] - gravity[1];
            linear_acceleration[2] = event.values[2] - gravity[2];

            // Determine the activity based on the accelerometer data
            int activity = getActivity(linear_acceleration);

            // Update the status text view
            String status;
            switch (activity) {
                case 0:
                    status = "Standing";
                    break;
                case 1:
                    status = "Sitting";
                    break;
                case 2:
                    status = "Walking";
                    break;
                case 3:
                    status = "Jumping";
                    break;
                default:
                    status = "Unknown";
            }
            statusTextView.setText(status);

            // Set the color of the status text view based on the activity
            switch (activity) {
                case 0:
                    statusTextView.setTextColor(Color.BLUE);
                    break;
                case 1:
                    statusTextView.setTextColor(Color.BLACK);
                    break;
                case 2:
                    statusTextView.setTextColor(Color.BLACK);
                    break;
                case 3:
                    statusTextView.setTextColor(Color.BLACK);
                    break;
            }

            // Update the confidence values in the table
            confidenceValues[activity] += 1;
            int totalConfidence = 0;
            for (int i = 0; i < confidenceValues.length; i++) {
                totalConfidence += confidenceValues[i];
            }
            if (totalConfidence > 0) {
                activityStandingConfidenceTextView.setText((confidenceValues[0] * 100 / totalConfidence) + "%");
                activitySittingConfidenceTextView.setText((confidenceValues[1] * 100 / totalConfidence) + "%");
                activityWalkingConfidenceTextView.setText((confidenceValues[2] * 100 / totalConfidence) + "%");
                activityJumpingConfidenceTextView.setText((confidenceValues[3] * 100 / totalConfidence) + "%");
                // Set the background color of the activity with the highest confidence to blue
                int maxConfidenceIndex = 0;
                int maxConfidenceValue = confidenceValues[0];
                for (int i = 1; i < confidenceValues.length; i++) {
                    if (confidenceValues[i] > maxConfidenceValue) {
                        maxConfidenceIndex = i;
                        maxConfidenceValue = confidenceValues[i];
                    }
                }
                switch (maxConfidenceIndex) {
                    case 0:
                        activityStandingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.blue));
                        break;
                    case 1:
                        activitySittingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.blue));
                        break;
                    case 2:
                        activityWalkingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.blue));
                        break;
                    case 3:
                        activityJumpingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.blue));
                        break;
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    private int getActivity(float[] acceleration) {
        // Determine the activity based on the accelerometer data
        int activity;
        float x = acceleration[0];
        float y = acceleration[1];
        float z = acceleration[2];

        float magnitude = (float) Math.sqrt(x * x + y * y + z * z);

        if (magnitude < 2.0f) {
            activity = 0; // Standing
        } else if (magnitude < 5.0f) {
            activity = 1; // Sitting
        } else if (magnitude < 8.0f) {
            activity = 2; // Walking
        } else {
            activity = 3; // Jumping
        }
        return activity;
    }
}